RingoFluidEmitter
(c) 2009 by RingoStar
ringo.downunder@googlemail.com

Usage:

Create by typing: createNode ringoFluidEmitter;

Then connect fluid to emitter via Dynamic Relationship Editor.
Connect any per particle Attributes to the inputs of the emitter.

Examples:
	worldPosition --> inPosition
	worldVelocity --> inVelocity
	radiusPP --> inRadii
	densityPP --> inDensity
	rgbPP --> inRGB

Velocity can be multiplied by InheritVelocity in the extras tab.

Please let me know if you find bugs.

Enjoy

Ringo

